Python 3.9.5 (v3.9.5:0a7dcbdb13, May  3 2021, 13:17:02) 
[Clang 6.0 (clang-600.0.57)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
>>> #CTI-110
>>> #P3LAB2b: Initials
>>> #Richard Edge
>>> #24 June 2021
>>> 
>>> # THe Letter R
>>> import turtle
>>> turtle.showturtle()
>>> turtle.pencolor('blue')
>>> turtle.pensize(3)
>>> turtle.pensize('3')
>>> turtle.penup()
>>> turtle.right(180)
>>> turtle.forward(200)
>>> turtle.right(90)
>>> turtle.pendown()
>>> turtle.forward(150)
>>> turtle.right(90)
>>> turtle.forward(75)
>>> turtle.right(90)
>>> turtle.forward(60)
>>> turtle.right(90)
>>> turtle.forward(75)
>>> turtle.left(90)
>>> turtle.left(45)
>>> turtle.forward(150)
>>> turtle.left(45)
>>> turtle.penup()
>>> turtle.forward(200)
>>> 
>>> #The Letter E
>>> 
>>> turtle.right(180)
>>> turtle.pendown()
>>> turtle.forward(100)
>>> turtle.right(90)
>>> turtle.forward(75)
>>> turtle.right(90)
>>> turtle.forward(40)
>>> turtle.right(180)
>>> turtle.forward(40)
>>> turtle.right(90)
>>> turtle.forward(75)
>>> turtle.right(90)
>>> turtle.forward(85)
>>> 