#CTI-110
#P4HW2 - Distance traveled
#Richard Edge
#30 June 2021

def main():

    # Initialize the "choice" variable to y so that the program at least runs once.
    choice = 'y'

    # Main loop, determines when to exit if the user doesn't want to enter any more times.
    while choice=='y':

        # Enter the speed of the car
        speed=float(input("Enter car's speed: "))

        # Enter the time traveled 
        time=float(input("Enter time traveled: ")) 

        # Since time must be positive, the loop continues to ask for the value of time
        # traveled if the input is <=0
        while(time<=0):
            print("Error! time entered should be <=0")
            time=float(input("Enter time traveled: "))

        # If the user entered a positive time value, the output can be generated.

        #Output Time and Distance traveled in tabular form    
        print("\nTime\tDistance")
        print("-"*17)
        count=1
        while count<=time:
            #Distance traveled= speed*time
            print(count,"\t",count*speed) 
            count+=1

                
        #Ask the user if he or she would like to run the program again, 
        #and if so enter a different number of hours.
        #Ask user if they would like to enter a different time
        choice=input("\nWould you like to enter a different time? (y for yes): ") 

    
main()
