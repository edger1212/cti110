#CTI-110
#P3HW2 - Distance traveled
#Richard Edge
#23 June 2021
#
'''
Input the car's speed
Input the time traveled

If the time is equal or less than zero
    print "Error ! time entered should be >0"
    Set time to 1
Set the distance to speed times time
Print the speed
Print the time
Print the distance

'''
#ask user to enter speed and time
speed=float(input("Enter car's speed: "))
time=int(input("Enter time traveled: "))
# if time is less than or equal to zero
if(time<=0):
    print("\nError ! time entered should be >0")
    time=1
#calculate the cars distance
distance=speed*time
#print the speed,time and the distance
print("\nSpeed entered: {}".format(speed))
print("Time : {}".format(time))
print("Distance Traveled {} miles".format(distance))
