Python 3.9.5 (v3.9.5:0a7dcbdb13, May  3 2021, 13:17:02) 
[Clang 6.0 (clang-600.0.57)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
================= RESTART: /Users/Edge1278/Desktop/distance.py =================
Enter car's speed: 70
Enter time traveled: -1

Error ! time entered should be >0

Speed entered: 70.0
Time : 1
Distance Traveled 70.0 miles
>>> 