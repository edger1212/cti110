#CTI-110
#P4HW1 - Expenses
#Richard Edge
#30-June-2021

def main():
    balance = float(input('Enter starting amount in account: $'))
    print()
    # What is the current expense entered by the user?
    # What are the total expenses entered by user?
    # Create a counter for the expenses
    current_expense = 0.0
    total_expense = 0.0
    num_expenses = 0
    # Add the line asking the user if he or she would like to enter another expense
    yes_no = '\0'
    
    # now start the loop until the user enters a 'n' or 'N'
    while yes_no != 'n' and yes_no != 'N':
        
	    # have the user enter his or her expenses one by one
	    current_expense = float(input("Enter expense {0}: ".format((num_expenses + 1))))
	    # add the number of expenses by +=1
	    num_expenses += 1
	    
	    # add the total expense to the current expenses amount
	    total_expense += current_expense
	    
	    # now ask the user if he or she needs to enter another expense
	    yes_no = input('Do you want to enter another expense?(y/n) ')
	    
	    # if the user chooses 'n', then display the results and then exit the loop
	    if yes_no == 'n' or yes_no == 'N':
		    print("\nAmount in account before expenses subtracted: ${0:.1f}".format(balance))
		    # add the line 'balance after subtracting the total expense'
		    balance -= total_expense
		    # now add the print the number of expenses line
		    print("Number of expenses entered: {0}".format(num_expenses))
		    # print the balance after subtracting the total expense
		    print("Amount in account after expenses subtracted: ${0:.1f}".format(balance))
		    # exit the loop
		    print()

		
main()
